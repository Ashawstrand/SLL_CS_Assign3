﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_Skeleton.Utility
{
    //Singly linked list implementation of LinkedListADT
    public class SLL : LinkedListADT
    {
        //Pointer to the head node of the list.
        private Node head;
        //Count of elements in the list.
        private int size;

        //Initializes an empty list.
        public SLL()
        {
            head = null;
            size = 0;
        }


        //Appends data to the end of the list.
        public void Append(object data)
        {
            //Check if data is null
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            //Create a new node with the data.
            Node newNode = new Node(data);

            //If the list is empty, set head to the new node.
            if (IsEmpty())
            {
                //set head to new node
                head = newNode;
            }

            else
            {
                //start at the head node and go through the list
                Node current = head;

                //while the next node is not null, move to the next node
                while (current.Next != null)
                {
                    //go to next node
                    current = current.Next;
                }

                //set the next node to the new node
                current.Next = newNode;
            }
            //Increment the size of the list.
            size++;
        }

        //Clears the list.
        public void Clear()
        {   //set head and size to null/0
            head = null;
            size = 0;
        }

        //Go through elements and check if we have one with data.
        //parameter data Data object to search for.
        //return True if element exists with value.
        public bool Contains(object data)
        {
            return IndexOf(data) != -1;
        }

        //Removes element at index from list.
        public void Delete(int index)
        {
            //check if index is out of range
            if (index < 0 || index >= size)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }

            //if index is 0 (want to remove first item), move head pointer to the next node
            if (index == 0)
            {
                //skips over first node
                head = head.Next;
                //decrement size
                size--;
                return;
            }

            //if index is not 0, we need to traverse the list to find the node before the index
            Node current = head;
            for (int i = 0; i < index - 1; i++)
            {
                //Traverse the list to find the node before the index
                current = current.Next;
            }

            //Skip over the node at the index ... efectively removing it
            current.Next = current.Next.Next;
            size--;


        }

        //Gets the first index of element containing data.
        //parameter data Data object to find the first index of.
        //return First of index of element with matching data or -1 if not found.
        public int IndexOf(object data)
        {
            //starting indexing at the head
            Node current = head;
            int index = 0;

            //go through the list until we find the data or reach the end
            while (current != null)
            {
                //Check if the current node's data matches the data we're looking for
                if (current.Data.Equals(data))
                {
                    //If it does, return the index
                    return index;
                }
                //Move to the next node
                current = current.Next;
                index++;
            }
            //If we reach here, the data was not found, return -1
            return -1;
        }

        //Adds a new element at a specific position.
        //parameter data Data that element is to contain.
        //parameter index Index to add new element at.
        //throws exception IndexOutOfRangeException Thrown if index is negative or past the size of the list.
        public void Insert(object data, int index)
        {
            //Check if data is null
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }
            //Check if index is negative or larger than size
            if (index < 0 || index > size)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }

            //if list is empty and index is 0, prepend the data
            if (index == 0)
            {
                Prepend(data);
                return;
            }

            //if list is not empty and index is not 0
            Node newNode = new Node(data);
            Node current = head;
            //Traverse the list to find the node before the index
            for (int i = 0; i < index - 1; i++)
            {
                current = current.Next;
            }
            //Insert the new node at the index
            //Set the next node of the new node to the next node of the current node
            newNode.Next = current.Next;
            //Set the next node of the current node to the new node
            current.Next = newNode;
            size++;
        }

        //Checks if the list is empty.
        public bool IsEmpty()
        {
            //check if true
            return size == 0;
        }

        //Prepends (adds to beginning) data to the list.
        public void Prepend(object data)
        {
            //Check if data is null
            if (data == null)
                throw new ArgumentNullException(nameof(data));

            //Create a new node with the data.
            Node newNode = new Node(data);
            //make the head the next node of the new node.
            newNode.Next = head;
            //Set the head to the new node.
            head = newNode;
            //Increment the size of the list.
            size++;
        }

        //Replaces the data at index.
        public void Replace(object data, int index)
        {
            //Check if data is null
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            //check if index is out of range / equal to size is appending
            if (index < 0 || index >= size)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }

            Node current = head;
            //Traverse the list to find the node at the index
            for (int i = 0; i < index; i++)
            {
                //Move to the next node
                current = current.Next;
            }
            //Set the data of the current node to the new data
            current.Data = data;
        }


        //Gets the data at the specified index.
        public object Retrieve(int index)
        {
            //Check if index is out of range
            if (index < 0 || index >= size)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }

            Node current = head;
            //Traverse the list to find the node at the index
            for (int i = 0; i < index; i++)
            {
                //Move to the next node
                current = current.Next;
            }

            //get the data of the current node
            return current.Data;
        }

        //Gets the number of elements in the list.
        public int Size()
        {
            return size;
        }

        //To Array Additional Method
        //Copy the values of the linked list to an array.
        public object[] ToArray()
        {
            //Create an array of the size of the list.
            object[] result = new object[size];
            Node current = head;
            //Traverse the list and copy the data to the array.
            for (int i = 0; i < size; i++)
            {
                result[i] = current.Data;
                current = current.Next;
            }
            return result;
        }
    }
}
