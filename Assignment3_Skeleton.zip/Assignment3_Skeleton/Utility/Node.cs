﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_Skeleton.Utility
{
    //Node class for linked list.
    public class Node
    {
        //Data part of the node.
        public object Data { get; set; }

        //Pointer to the next node in the list.
        public Node Next { get; set; }

        //Initializes a node with data.
        public Node(object data)
        {
            Data = data;
            Next = null;
        }
    }
}
