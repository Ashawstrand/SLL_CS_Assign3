﻿using Assignment3_Skeleton.Utility;
using System;
using Xunit;

namespace Test_Assignment_3
{
    public class LinkedListTests : IDisposable
    {
        private LinkedListADT linkedList;

        public LinkedListTests()
        {
            // Setup: Create your concrete linked list class and assign to linkedList.
            this.linkedList = new SLL();
        }

        public void Dispose()
        {
            // Teardown: Clear the linked list after each test.
            this.linkedList.Clear();
        }

        // Test the linked list is empty.
        [Fact]
        public void TestIsEmpty()
        {
            Assert.True(this.linkedList.IsEmpty());
            Assert.Equal(0, this.linkedList.Size());
        }

        // Tests appending elements to the linked list.
        [Fact]
          public void TestAppendNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            Assert.False(this.linkedList.IsEmpty());
            Assert.Equal(4, this.linkedList.Size());
            Assert.Equal("a", this.linkedList.Retrieve(0));
            Assert.Equal("b", this.linkedList.Retrieve(1));
            Assert.Equal("c", this.linkedList.Retrieve(2));
            Assert.Equal("d", this.linkedList.Retrieve(3));
        }

        // Tests prepending nodes to linked list.
        [Fact]
        public void TestPrependNodes()
        {
            this.linkedList.Prepend("a");
            this.linkedList.Prepend("b");
            this.linkedList.Prepend("c");
            this.linkedList.Prepend("d");

            Assert.False(this.linkedList.IsEmpty());
            Assert.Equal(4, this.linkedList.Size());
            Assert.Equal("d", this.linkedList.Retrieve(0));
            Assert.Equal("c", this.linkedList.Retrieve(1));
            Assert.Equal("b", this.linkedList.Retrieve(2));
            Assert.Equal("a", this.linkedList.Retrieve(3));
        }

        // Tests inserting node at valid index.
        [Fact]
        public void TestInsertNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Insert("e", 2);

            Assert.False(this.linkedList.IsEmpty());
            Assert.Equal(5, this.linkedList.Size());
            Assert.Equal("a", this.linkedList.Retrieve(0));
            Assert.Equal("b", this.linkedList.Retrieve(1));
            Assert.Equal("e", this.linkedList.Retrieve(2));
            Assert.Equal("c", this.linkedList.Retrieve(3));
            Assert.Equal("d", this.linkedList.Retrieve(4));
        }

        // Tests replacing existing nodes data.
        [Fact]
        public void TestReplaceNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Replace("e", 2);

            Assert.False(this.linkedList.IsEmpty());
            Assert.Equal(4, this.linkedList.Size());
            Assert.Equal("a", this.linkedList.Retrieve(0));
            Assert.Equal("b", this.linkedList.Retrieve(1));
            Assert.Equal("e", this.linkedList.Retrieve(2));
            Assert.Equal("d", this.linkedList.Retrieve(3));
        }

        // Tests deleting node from linked list.
        [Fact]
        public void TestDeleteNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Delete(2);

            Assert.False(this.linkedList.IsEmpty());
            Assert.Equal(3, this.linkedList.Size());
            Assert.Equal("a", this.linkedList.Retrieve(0));
            Assert.Equal("b", this.linkedList.Retrieve(1));
            Assert.Equal("d", this.linkedList.Retrieve(2));
        }

        // Tests finding and retrieving node in linked list.
        [Fact]
        public void TestFindNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            bool contains = this.linkedList.Contains("b");
            Assert.True(contains);

            int index = this.linkedList.IndexOf("b");
            Assert.Equal(1, index);

            string value = (string)this.linkedList.Retrieve(1);
            Assert.Equal("b", value);
        }

        //Test for additional function of TestToArray

        [Fact]

        public void TestToArray()
        {
            //test empty array
            object[] emptyArray = ((SLL)this.linkedList).ToArray();
            Assert.Empty(emptyArray);
            
            //test single node
            this.linkedList.Append("a");
            object[] singleArray = ((SLL)this.linkedList).ToArray();
            Assert.Single(singleArray);
            Assert.Equal("a", singleArray[0]);

            //test multiple nodes
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");
            object[] multipleArray = ((SLL)this.linkedList).ToArray();
            Assert.Equal(4, multipleArray.Length);
            Assert.Equal("a", multipleArray[0]);
            Assert.Equal("b", multipleArray[1]);
            Assert.Equal("c", multipleArray[2]);
            Assert.Equal("d", multipleArray[3]);

        }
    }
}
