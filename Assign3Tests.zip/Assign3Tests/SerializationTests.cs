﻿using Assignment3_Skeleton;
using Assignment3_Skeleton.ProblemDomain;
using System;
using System.Collections.Generic;
using System.IO;
using Xunit;

namespace Test_Assignment_3
{
    public class SerializationTests : IDisposable
    {
        private List<User> users;
        private readonly string testFileName;

        public SerializationTests()
        {
            users = new List<User>();
            users.Add(new User(1, "Joe Blow", "jblow@gmail.com", "password"));
            users.Add(new User(2, "Joe Schmoe", "joe.schmoe@outlook.com", "abcdef"));
            users.Add(new User(3, "Colonel Sanders", "chickenlover1890@gmail.com", "kfc5555"));
            users.Add(new User(4, "Ronald McDonald", "burgers4life63@outlook.com", "mcdonalds999"));
            testFileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "test_users.bin");
        }

        public void Dispose()
        {
            users.Clear();
            if (File.Exists(testFileName))
                File.Delete(testFileName);
        }

        [Fact]
        public void TestSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            Assert.True(File.Exists(testFileName));
        }

        [Fact]
        public void TestDeSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            List<User> deserializedUsers = SerializationHelper.DeserializeUsers(testFileName);
            Assert.Equal(users.Count, deserializedUsers.Count);
            for (int i = 0; i < users.Count; i++)
            {
                Assert.Equal(users[i].getId(), deserializedUsers[i].getId());
                Assert.Equal(users[i].getName(), deserializedUsers[i].getName());
                Assert.Equal(users[i].getEmail(), deserializedUsers[i].getEmail());
                Assert.Equal(users[i].Password, deserializedUsers[i].Password);
            }
        }
    }
}
